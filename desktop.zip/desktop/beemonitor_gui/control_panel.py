"""
Control Panel
=============

Left sidebar control panel with detection parameters and actions.
"""

from PyQt6.QtWidgets import (
    QScrollArea, QWidget, QVBoxLayout, QGroupBox,
    QPushButton, QLabel, QSlider
)
from PyQt6.QtCore import Qt, pyqtSignal

from .constants import DETECTION_PRESETS


class ControlPanel(QScrollArea):
    """Control panel with detection parameters and action buttons."""
    
    # Signals
    test_detection_requested = pyqtSignal()
    initialize_background_requested = pyqtSignal()
    run_analysis_requested = pyqtSignal()
    load_video_requested = pyqtSignal()
    parameters_changed = pyqtSignal(dict)
    preset_loaded = pyqtSignal(str)
    
    def __init__(self):
        """Initialize control panel."""
        super().__init__()
        self.setWidgetResizable(True)
        self.setMinimumWidth(380)
        
        container = QWidget()
        layout = QVBoxLayout()
        container.setLayout(layout)
        
        # Add sections
        layout.addWidget(self._create_video_group())
        layout.addWidget(self._create_parameters_group())
        layout.addWidget(self._create_presets_group())
        layout.addWidget(self._create_actions_group())
        layout.addStretch()
        
        self.setWidget(container)
    
    def _create_video_group(self):
        """Create video info section."""
        video_group = QGroupBox("Video")
        video_layout = QVBoxLayout()
        
        load_btn = QPushButton("📁 Load Video")
        load_btn.clicked.connect(self.load_video_requested.emit)
        video_layout.addWidget(load_btn)
        
        self.video_info_label = QLabel("No video loaded")
        self.video_info_label.setWordWrap(True)
        video_layout.addWidget(self.video_info_label)
        
        self.output_folder_label = QLabel("<i>Output: (load video first)</i>")
        self.output_folder_label.setWordWrap(True)
        self.output_folder_label.setStyleSheet("color: #666; font-size: 9pt;")
        video_layout.addWidget(self.output_folder_label)
        
        video_group.setLayout(video_layout)
        return video_group
    
    def _create_parameters_group(self):
        """Create detection parameter sliders."""
        params_group = QGroupBox("Detection Parameters")
        params_layout = QVBoxLayout()
        
        # Min Area
        params_layout.addWidget(QLabel("Min Area (px²):"))
        self.min_area_slider = QSlider(Qt.Orientation.Horizontal)
        self.min_area_slider.setMinimum(30)
        self.min_area_slider.setMaximum(300)
        self.min_area_slider.setValue(120)
        self.min_area_slider.valueChanged.connect(self._on_param_change)
        params_layout.addWidget(self.min_area_slider)
        self.min_area_label = QLabel("120")
        self.min_area_label.setAlignment(Qt.AlignmentFlag.AlignRight)
        params_layout.addWidget(self.min_area_label)
        
        # Min Solidity
        params_layout.addWidget(QLabel("Min Solidity (0-1):"))
        self.min_solidity_slider = QSlider(Qt.Orientation.Horizontal)
        self.min_solidity_slider.setMinimum(30)
        self.min_solidity_slider.setMaximum(95)
        self.min_solidity_slider.setValue(70)
        self.min_solidity_slider.valueChanged.connect(self._on_param_change)
        params_layout.addWidget(self.min_solidity_slider)
        self.min_solidity_label = QLabel("0.70")
        self.min_solidity_label.setAlignment(Qt.AlignmentFlag.AlignRight)
        params_layout.addWidget(self.min_solidity_label)
        
        # Max Area
        params_layout.addWidget(QLabel("Max Area (px²):"))
        self.max_area_slider = QSlider(Qt.Orientation.Horizontal)
        self.max_area_slider.setMinimum(1000)
        self.max_area_slider.setMaximum(10000)
        self.max_area_slider.setValue(4000)
        self.max_area_slider.valueChanged.connect(self._on_param_change)
        params_layout.addWidget(self.max_area_slider)
        self.max_area_label = QLabel("4000")
        self.max_area_label.setAlignment(Qt.AlignmentFlag.AlignRight)
        params_layout.addWidget(self.max_area_label)
        
        params_group.setLayout(params_layout)
        return params_group
    
    def _create_presets_group(self):
        """Create preset buttons."""
        presets_group = QGroupBox("Presets")
        presets_layout = QVBoxLayout()
        
        for name, preset_id in [
            ("Sensitive", "sensitive"),
            ("Default", "default"),
            ("Conservative ⭐", "conservative"),
            ("Very Conservative", "very_conservative")
        ]:
            btn = QPushButton(name)
            btn.clicked.connect(lambda checked, p=preset_id: self._load_preset(p))
            presets_layout.addWidget(btn)
        
        presets_group.setLayout(presets_layout)
        return presets_group
    
    def _create_actions_group(self):
        """Create action buttons."""
        actions_group = QGroupBox("Actions")
        actions_layout = QVBoxLayout()
        
        init_bg_btn = QPushButton("Initialize Background")
        init_bg_btn.clicked.connect(self.initialize_background_requested.emit)
        actions_layout.addWidget(init_bg_btn)
        
        test_btn = QPushButton("Test Detection (Space)")
        test_btn.clicked.connect(self.test_detection_requested.emit)
        actions_layout.addWidget(test_btn)
        
        analyze_btn = QPushButton("▶ Run Full Analysis")
        analyze_btn.setStyleSheet(
            "background-color: #4CAF50; color: white; "
            "font-weight: bold; padding: 10px;"
        )
        analyze_btn.clicked.connect(self.run_analysis_requested.emit)
        actions_layout.addWidget(analyze_btn)
        
        self.detection_count_label = QLabel("Detections: 0")
        self.detection_count_label.setStyleSheet(
            "font-size: 12pt; font-weight: bold;"
        )
        self.detection_count_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        actions_layout.addWidget(self.detection_count_label)
        
        actions_group.setLayout(actions_layout)
        return actions_group
    
    def _on_param_change(self):
        """Handle parameter slider changes."""
        params = self.get_parameters()
        
        self.min_area_label.setText(str(params['min_area']))
        self.min_solidity_label.setText(f"{params['min_solidity']:.2f}")
        self.max_area_label.setText(str(params['max_area']))
        
        self.parameters_changed.emit(params)
    
    def _load_preset(self, preset_name):
        """Load parameter preset."""
        if preset_name not in DETECTION_PRESETS:
            return
        
        preset = DETECTION_PRESETS[preset_name]
        
        self.min_area_slider.setValue(preset["min_area"])
        self.min_solidity_slider.setValue(preset["min_solidity"])
        self.max_area_slider.setValue(preset["max_area"])
        
        self.preset_loaded.emit(preset_name)
    
    def get_parameters(self):
        """Get current parameter values."""
        return {
            'min_area': self.min_area_slider.value(),
            'min_solidity': self.min_solidity_slider.value() / 100.0,
            'max_area': self.max_area_slider.value()
        }
    
    def set_parameters(self, params):
        """Set parameter values."""
        if 'min_area' in params:
            self.min_area_slider.setValue(int(params['min_area']))
        if 'min_solidity' in params:
            self.min_solidity_slider.setValue(int(params['min_solidity'] * 100))
        if 'max_area' in params:
            self.max_area_slider.setValue(int(params['max_area']))
    
    def set_detection_count(self, count):
        """Update detection count label."""
        self.detection_count_label.setText(f"Detections: {count}")
    
    def set_video_info(self, text):
        """Update video info label."""
        self.video_info_label.setText(text)
    
    def set_output_folder_info(self, text):
        """Update output folder label."""
        self.output_folder_label.setText(text)
