"""
BeeTracker - v2.2 ADAPTIVE (Resolution & FPS Independent)
==========================================================

Enhanced multi-object tracking with ADAPTIVE thresholds based on bee size and FPS.

v2.2 Changes:
- All distance thresholds as MULTIPLIERS of bee size
- All time thresholds as RATIOS of FPS
- Resolution-independent tracking
- FPS-independent tracking

Key Features:
- Adaptive to different video resolutions
- Adaptive to different frame rates
- Consistent behavior across videos
"""

import numpy as np
from scipy.optimize import linear_sum_assignment
from collections import defaultdict, deque
from typing import List, Tuple, Optional, Dict
import logging

logger = logging.getLogger(__name__)


class KalmanFilter:
    """Simple Kalman filter for 2D position tracking."""
    
    def __init__(self, initial_position, process_noise=1.0, measurement_noise=1.0):
        """
        Initialize Kalman filter.
        
        Args:
            initial_position: (x, y) initial position
            process_noise: Process noise covariance
            measurement_noise: Measurement noise covariance
        """
        x, y = initial_position
        self.state = np.array([x, y, 0, 0], dtype=float)  # [x, y, vx, vy]
        
        # State transition matrix
        self.F = np.array([
            [1, 0, 1, 0],
            [0, 1, 0, 1],
            [0, 0, 1, 0],
            [0, 0, 0, 1]
        ], dtype=float)
        
        # Measurement matrix
        self.H = np.array([
            [1, 0, 0, 0],
            [0, 1, 0, 0]
        ], dtype=float)
        
        # Covariance matrices
        self.P = np.eye(4) * 500  # Initial uncertainty
        self.Q = np.eye(4) * process_noise
        self.R = np.eye(2) * measurement_noise
    
    def predict(self):
        """Predict next state."""
        self.state = self.F @ self.state
        self.P = self.F @ self.P @ self.F.T + self.Q
        return self.state[:2]
    
    def update(self, measurement):
        """Update state with measurement."""
        measurement = np.array(measurement)
        y = measurement - (self.H @ self.state)
        S = self.H @ self.P @ self.H.T + self.R
        K = self.P @ self.H.T @ np.linalg.inv(S)
        self.state = self.state + K @ y
        self.P = (np.eye(4) - K @ self.H) @ self.P
        return self.state[:2]
    
    @property
    def position(self):
        """Get current position estimate."""
        return self.state[:2]
    
    @property
    def velocity(self):
        """Get current velocity estimate."""
        return self.state[2:]


class Track:
    """Represents a single tracked object (bee)."""
    
    _next_id = 1
    
    def __init__(self, detection, frame_num, min_hits=3, max_age=30):
        """
        Initialize track.
        
        Args:
            detection: Initial detection (x1, y1, x2, y2)
            frame_num: Frame number where track started
            min_hits: Minimum hits before track is confirmed
            max_age: Maximum frames without detection before deletion
        """
        self.id = Track._next_id
        Track._next_id += 1
        
        bbox = detection[:4]
        cx = (bbox[0] + bbox[2]) / 2
        cy = (bbox[1] + bbox[3]) / 2
        
        self.kf = KalmanFilter((cx, cy))
        self.history = deque(maxlen=30)
        self.history.append((cx, cy))
        
        self.hits = 1
        self.age = 0
        self.time_since_update = 0
        self.min_hits = min_hits
        self.max_age = max_age
        
        self.last_bbox = bbox
        self.last_detection_frame = frame_num
        self.start_frame = frame_num
        
        # Anti-duplicate tracking
        self.initial_position = (cx, cy)
        self.position_variance = 0.0
        self.is_stable = False
    
    def predict(self):
        """Predict next position."""
        predicted_pos = self.kf.predict()
        self.age += 1
        self.time_since_update += 1
        return predicted_pos
    
    def update(self, detection, frame_num):
        """Update track with detection."""
        bbox = detection[:4]
        cx = (bbox[0] + bbox[2]) / 2
        cy = (bbox[1] + bbox[3]) / 2
        
        self.kf.update((cx, cy))
        self.history.append((cx, cy))
        
        self.hits += 1
        self.time_since_update = 0
        self.last_bbox = bbox
        self.last_detection_frame = frame_num
        
        # Update stability metrics
        if len(self.history) >= 5:
            recent_positions = np.array(list(self.history)[-5:])
            self.position_variance = np.var(recent_positions)
            self.is_stable = self.position_variance < 100
    
    @property
    def is_confirmed(self):
        """Check if track is confirmed."""
        return self.hits >= self.min_hits
    
    @property
    def is_dead(self):
        """Check if track should be deleted."""
        return self.time_since_update > self.max_age
    
    @property
    def centroid(self):
        """Get current centroid."""
        return self.kf.position
    
    def get_distance_to(self, position):
        """Get Euclidean distance to a position."""
        return np.linalg.norm(self.centroid - np.array(position))


class BeeTracker:
    """
    Adaptive bee tracking with resolution and FPS-independent thresholds.
    
    v2.2 Features:
    - All distance thresholds as multipliers of bee size
    - All time thresholds as ratios of FPS
    - Works across different resolutions and frame rates
    """
    
    def __init__(
        self,
        fps: float = 30.0,
        bee_size: Optional[float] = None,
        # Time thresholds (as ratios of FPS)
        max_age_seconds: float = 1.0,  # 1 second without detection
        min_hits_seconds: float = 0.1,  # 0.1 seconds to confirm (3 frames at 30fps)
        max_resurrection_seconds: float = 0.5,  # 0.5 seconds to resurrect
        # Distance thresholds (as multipliers of bee size)
        resurrection_search_multiplier: float = 1.5,  # 1.5x bee size
        duplicate_distance_multiplier: float = 1.2,  # 1.2x bee size
        # Other
        iou_threshold: float = 0.3
    ):
        """
        Initialize BeeTracker with ADAPTIVE thresholds.
        
        Args:
            fps: Video frame rate (frames per second)
            bee_size: Average bee size in pixels (auto-calculated if None)
            
            Time thresholds (in seconds):
                max_age_seconds: Max time without detection before track dies
                min_hits_seconds: Min time before track is confirmed
                max_resurrection_seconds: Max time to keep dead tracks for resurrection
            
            Distance thresholds (as multipliers of bee size):
                resurrection_search_multiplier: Search radius for resurrections
                duplicate_distance_multiplier: Distance for duplicate detection
            
            Other:
                iou_threshold: IoU threshold for matching
        """
        self.fps = fps
        self.bee_size = bee_size
        self.bee_size_calculated = False
        
        # Convert time thresholds to frames
        self.max_age = int(max_age_seconds * fps)
        self.min_hits = max(1, int(min_hits_seconds * fps))
        self.max_resurrection_frames = int(max_resurrection_seconds * fps)
        
        # Distance multipliers (will be applied to bee_size)
        self.resurrection_search_multiplier = resurrection_search_multiplier
        self.duplicate_distance_multiplier = duplicate_distance_multiplier
        
        self.iou_threshold = iou_threshold
        
        self.tracks: List[Track] = []
        self.dead_tracks: List[Tuple[Track, int]] = []
        self.frame_count = 0
        
        # Anti-duplicate tracking
        self.track_positions = defaultdict(list)
        self.confirmed_track_ids = set()
        
        # For adaptive bee size calculation
        self.detection_sizes = []
        
        logger.info(f"BeeTracker initialized (v2.2 ADAPTIVE):")
        logger.info(f"  FPS: {fps}")
        logger.info(f"  Max age: {max_age_seconds}s ({self.max_age} frames)")
        logger.info(f"  Min hits: {min_hits_seconds}s ({self.min_hits} frames)")
        logger.info(f"  Max resurrection: {max_resurrection_seconds}s ({self.max_resurrection_frames} frames)")
        logger.info(f"  Resurrection multiplier: {resurrection_search_multiplier}x bee size")
        logger.info(f"  Duplicate multiplier: {duplicate_distance_multiplier}x bee size")
    
    def _calculate_bee_size(self, detections):
        """
        Calculate average bee size from detections.
        
        Args:
            detections: List of detections (x1, y1, x2, y2, ...)
        """
        if len(detections) == 0:
            return
        
        for detection in detections:
            bbox = detection[:4]
            width = bbox[2] - bbox[0]
            height = bbox[3] - bbox[1]
            size = (width + height) / 2  # Average of width and height
            self.detection_sizes.append(size)
        
        # Calculate median (more robust than mean)
        if len(self.detection_sizes) >= 10:  # Wait for 10 detections
            self.bee_size = np.median(self.detection_sizes)
            self.bee_size_calculated = True
            logger.info(f"Calculated bee size: {self.bee_size:.1f} pixels")
    
    def _get_bee_size(self):
        """Get bee size (calculated or provided)."""
        if self.bee_size is not None:
            return self.bee_size
        elif self.bee_size_calculated:
            return np.median(self.detection_sizes)
        else:
            # Default fallback
            return 40.0
    
    def _calculate_iou(self, bbox1, bbox2):
        """Calculate IoU between two bounding boxes."""
        x1_min, y1_min, x1_max, y1_max = bbox1
        x2_min, y2_min, x2_max, y2_max = bbox2
        
        inter_x_min = max(x1_min, x2_min)
        inter_y_min = max(y1_min, y2_min)
        inter_x_max = min(x1_max, x2_max)
        inter_y_max = min(y1_max, y2_max)
        
        if inter_x_max < inter_x_min or inter_y_max < inter_y_min:
            return 0.0
        
        inter_area = (inter_x_max - inter_x_min) * (inter_y_max - inter_y_min)
        
        bbox1_area = (x1_max - x1_min) * (y1_max - y1_min)
        bbox2_area = (x2_max - x2_min) * (y2_max - y2_min)
        
        union_area = bbox1_area + bbox2_area - inter_area
        
        return inter_area / union_area if union_area > 0 else 0.0
    
    def _get_cost_matrix(self, detections):
        """Calculate cost matrix between tracks and detections."""
        if len(self.tracks) == 0 or len(detections) == 0:
            return np.array([])
        
        cost_matrix = np.zeros((len(self.tracks), len(detections)))
        
        for i, track in enumerate(self.tracks):
            track_pos = track.centroid
            
            for j, detection in enumerate(detections):
                bbox = detection[:4]
                det_cx = (bbox[0] + bbox[2]) / 2
                det_cy = (bbox[1] + bbox[3]) / 2
                det_pos = np.array([det_cx, det_cy])
                
                # Euclidean distance
                distance = np.linalg.norm(track_pos - det_pos)
                
                # IoU
                iou = self._calculate_iou(track.last_bbox, bbox)
                
                # Combined cost (lower is better)
                cost = distance * (1 - iou)
                cost_matrix[i, j] = cost
        
        return cost_matrix
    
    def _is_duplicate_track(self, track: Track) -> bool:
        """
        Check if track is a duplicate using ADAPTIVE distance threshold.
        
        Args:
            track: Track to check
            
        Returns:
            True if track is likely a duplicate
        """
        if not track.is_confirmed:
            return False
        
        # Get adaptive threshold
        bee_size = self._get_bee_size()
        duplicate_threshold = bee_size * self.duplicate_distance_multiplier
        
        track_pos = np.array(track.centroid)
        
        # Check against all confirmed tracks
        for other_id in self.confirmed_track_ids:
            if other_id == track.id:
                continue
            
            # Find the other track
            other_track = None
            for t in self.tracks:
                if t.id == other_id:
                    other_track = t
                    break
            
            if other_track is None:
                continue
            
            # Check distance
            other_pos = np.array(other_track.centroid)
            distance = np.linalg.norm(track_pos - other_pos)
            
            if distance < duplicate_threshold:
                # Close tracks - check which is older/more stable
                if other_track.hits > track.hits:
                    logger.debug(f"Track {track.id} is duplicate of {other_track.id} (distance: {distance:.1f} < {duplicate_threshold:.1f})")
                    return True
                elif other_track.hits == track.hits and other_track.is_stable and not track.is_stable:
                    return True
        
        return False
    
    def _try_resurrect(self, detection, frame_num):
        """
        Try to resurrect a dead track using ADAPTIVE search radius.
        
        Args:
            detection: Detection to match
            frame_num: Current frame number
            
        Returns:
            Resurrected track if successful, None otherwise
        """
        if not self.dead_tracks:
            return None
        
        bbox = detection[:4]
        det_cx = (bbox[0] + bbox[2]) / 2
        det_cy = (bbox[1] + bbox[3]) / 2
        det_pos = np.array([det_cx, det_cy])
        
        best_track = None
        best_distance = float('inf')
        
        # Calculate ADAPTIVE search radius
        bee_size = self._get_bee_size()
        search_radius = bee_size * self.resurrection_search_multiplier
        
        logger.debug(f"Resurrection search radius: {search_radius:.1f} pixels ({self.resurrection_search_multiplier}x {bee_size:.1f})")
        
        for track, frame_died in self.dead_tracks[:]:
            # Remove tracks that have been dead too long
            if frame_num - frame_died > self.max_resurrection_frames:
                self.dead_tracks.remove((track, frame_died))
                continue
            
            # Check distance
            distance = track.get_distance_to(det_pos)
            
            # STRICTER resurrection criteria
            if distance < search_radius and distance < best_distance:
                # Additional checks for resurrection
                frames_dead = frame_num - frame_died
                
                # Prefer tracks that just died recently
                time_penalty = frames_dead / self.max_resurrection_frames
                adjusted_distance = distance * (1 + time_penalty)
                
                if adjusted_distance < best_distance:
                    best_distance = adjusted_distance
                    best_track = track
        
        if best_track is not None:
            # Resurrect track
            logger.debug(f"Resurrecting track {best_track.id} (distance: {best_distance:.1f}, radius: {search_radius:.1f})")
            self.dead_tracks = [(t, f) for t, f in self.dead_tracks if t.id != best_track.id]
            best_track.update(detection, frame_num)
            return best_track
        
        return None
    
    def update(self, detections, frame_num=None):
        """
        Update tracks with new detections.
        
        Args:
            detections: List of detections (x1, y1, x2, y2, ...)
            frame_num: Current frame number
            
        Returns:
            List of active track IDs and their centroids
        """
        if frame_num is None:
            frame_num = self.frame_count
        self.frame_count = frame_num
        
        # Calculate bee size if not yet done
        if not self.bee_size_calculated and self.bee_size is None:
            self._calculate_bee_size(detections)
        
        # Predict all tracks
        for track in self.tracks:
            track.predict()
        
        # Calculate cost matrix
        cost_matrix = self._get_cost_matrix(detections)
        
        # Hungarian assignment
        matched_tracks = set()
        matched_detections = set()
        
        if cost_matrix.size > 0:
            row_indices, col_indices = linear_sum_assignment(cost_matrix)
            
            for row, col in zip(row_indices, col_indices):
                cost = cost_matrix[row, col]
                
                # Apply adaptive threshold
                track = self.tracks[row]
                detection = detections[col]
                bbox = detection[:4]
                
                iou = self._calculate_iou(track.last_bbox, bbox)
                
                # Adaptive distance threshold
                bee_size = self._get_bee_size()
                max_distance = bee_size * 5.0  # 5x bee size for matching
                
                if cost < max_distance and iou > self.iou_threshold:
                    track.update(detection, frame_num)
                    matched_tracks.add(row)
                    matched_detections.add(col)
        
        # Handle unmatched detections
        unmatched_detections = set(range(len(detections))) - matched_detections
        
        for det_idx in unmatched_detections:
            detection = detections[det_idx]
            
            # Try resurrection first (with ADAPTIVE radius)
            resurrected = self._try_resurrect(detection, frame_num)
            if resurrected is not None:
                self.tracks.append(resurrected)
            else:
                # Create new track
                new_track = Track(detection, frame_num, self.min_hits, self.max_age)
                self.tracks.append(new_track)
        
        # Remove dead/duplicate tracks
        active_tracks = []
        for track in self.tracks:
            if track.is_dead:
                # Move to dead tracks for potential resurrection
                self.dead_tracks.append((track, frame_num))
                logger.debug(f"Track {track.id} died at frame {frame_num}")
            elif self._is_duplicate_track(track):
                # Remove duplicate
                logger.debug(f"Removing duplicate track {track.id}")
            else:
                active_tracks.append(track)
                if track.is_confirmed:
                    self.confirmed_track_ids.add(track.id)
        
        self.tracks = active_tracks
        
        # Return confirmed tracks
        results = []
        for track in self.tracks:
            if track.is_confirmed:
                results.append({
                    'track_id': track.id,
                    'centroid': tuple(track.centroid),
                    'bbox': track.last_bbox,
                    'history': list(track.history)
                })
        
        return results
    
    def get_active_tracks(self):
        """Get all confirmed active tracks."""
        return [
            {
                'track_id': track.id,
                'centroid': tuple(track.centroid),
                'bbox': track.last_bbox,
                'history': list(track.history)
            }
            for track in self.tracks if track.is_confirmed
        ]